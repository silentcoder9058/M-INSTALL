clear
pkg install metasploit
cd /data/data/com.termux/files/usr/opt
pwd
cp -rf /data/data/com.termux/files/usr/opt/metasploit-framework ~
echo " "
echo "done"
