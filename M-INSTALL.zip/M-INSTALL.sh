#cqolours
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
#coding section starts :)
clear
echo " "
echo " "


echo -e "$red
		███╗   ███╗      ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗     
		████╗ ████║      ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║     
		██╔████╔██║█████╗██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║     
		██║╚██╔╝██║╚════╝██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║     
		██║ ╚═╝ ██║      ██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗
		╚═╝     ╚═╝      ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝
										$grn<v1.0>
								$ylo</>code by$grn silentcoder9058$ylo</>
												"
#echo -e "$grn			>>>>>install metasploit<<<<<"

echo -e "$red warning!!!! It will not work properly for devices running Android 5.0 - 6.0>>>It is for 7.0+ Android"
echo " "
echo -e "$grn Are you happy to proceed? [y,n]"
read input

# did we get an input value?
if [[ "$input" == "y" ]] || [[ "$input" == "yes" ]]; then

cd ins

chmod 777 install.sh

pkg install unstable-repo

bash install.sh

else

cd dn
chmod 777 dis.sh
bash dis.sh

fi

